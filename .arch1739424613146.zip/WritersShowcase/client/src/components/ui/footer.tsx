import { Link } from "wouter";
import { Mail, Phone, MapPin } from "lucide-react";

export default function Footer() {
  const currentYear = new Date().getFullYear();

  const services = [
    "Article Writing",
    "Blog Posts",
    "Copywriting",
    "Editing & Proofreading",
    "Book Writing",
    "Ghost Writing",
    "Technical Writing",
    "Academic Writing"
  ];

  return (
    <footer className="border-t mt-16 bg-muted/30">
      <div className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div className="space-y-4">
            <h3 className="font-bold text-lg">About Me</h3>
            <p className="text-sm text-muted-foreground">
              Professional writer dedicated to crafting compelling content that engages and inspires readers across various domains.
            </p>
          </div>

          <div className="space-y-4">
            <h3 className="font-bold text-lg">Services</h3>
            <ul className="space-y-2">
              {services.map((service) => (
                <li key={service} className="text-sm text-muted-foreground hover:text-primary transition-colors">
                  <Link href="/services">{service}</Link>
                </li>
              ))}
            </ul>
          </div>

          <div className="space-y-4">
            <h3 className="font-bold text-lg">Quick Links</h3>
            <ul className="space-y-2">
              <li className="text-sm text-muted-foreground hover:text-primary transition-colors">
                <Link href="/">Home</Link>
              </li>
              <li className="text-sm text-muted-foreground hover:text-primary transition-colors">
                <Link href="/works">Portfolio</Link>
              </li>
              <li className="text-sm text-muted-foreground hover:text-primary transition-colors">
                <Link href="/contact">Contact</Link>
              </li>
            </ul>
          </div>

          <div className="space-y-4">
            <h3 className="font-bold text-lg">Contact</h3>
            <ul className="space-y-3">
              <li className="flex items-center gap-2 text-sm text-muted-foreground">
                <Mail className="w-4 h-4" />
                <span>contact@aimawriter.com</span>
              </li>
              <li className="flex items-center gap-2 text-sm text-muted-foreground">
                <Phone className="w-4 h-4" />
                <span>+1 (555) 123-4567</span>
              </li>
              <li className="flex items-center gap-2 text-sm text-muted-foreground">
                <MapPin className="w-4 h-4" />
                <span>New York, USA</span>
              </li>
            </ul>
          </div>
        </div>

        <div className="border-t mt-8 pt-8 text-center text-sm text-muted-foreground">
          <p>© {currentYear} Aima Writer. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
}
