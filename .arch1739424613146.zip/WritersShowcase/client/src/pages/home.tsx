import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { Work, FreelanceProfile } from "@shared/schema";
import { Clock } from "lucide-react";
import { SiX, SiLinkedin, SiMedium, SiFiverr, SiUpwork, SiBehance, SiFreelancer, SiDribbble, SiGithub, SiHashnode } from "react-icons/si";

export default function Home() {
  const { data: works, isLoading: isWorksLoading } = useQuery<Work[]>({ 
    queryKey: ["/api/works"],
    staleTime: 1000 * 60 * 5 // Cache for 5 minutes
  });

  const { data: freelanceProfiles, isLoading: isProfilesLoading } = useQuery<FreelanceProfile[]>({
    queryKey: ["/api/freelance-profiles"],
    staleTime: 1000 * 60 * 5 // Cache for 5 minutes
  });

  const platformIcons: Record<string, React.ComponentType> = {
    fiverr: SiFiverr,
    upwork: SiUpwork,
    behance: SiBehance,
    freelancer: SiFreelancer,
    dribbble: SiDribbble,
    github: SiGithub,
    hashnode: SiHashnode
  };

  // Loading skeleton for freelance profiles
  const ProfilesSkeleton = () => (
    <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
      {[1, 2, 3, 4].map((i) => (
        <Card key={i} className="animate-pulse">
          <CardContent className="p-6 flex flex-col items-center gap-3">
            <div className="w-8 h-8 bg-muted rounded-full" />
            <div className="h-4 bg-muted rounded w-20" />
          </CardContent>
        </Card>
      ))}
    </div>
  );

  // Loading skeleton for works
  const WorksSkeleton = () => (
    <div className="grid md:grid-cols-2 gap-6">
      {[1, 2].map((i) => (
        <Card key={i} className="animate-pulse">
          <CardContent className="p-6 space-y-4">
            <div className="w-full h-48 bg-muted rounded-md" />
            <div className="space-y-2">
              <div className="h-6 bg-muted rounded w-3/4" />
              <div className="h-4 bg-muted rounded w-full" />
              <div className="h-4 bg-muted rounded w-1/4" />
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );

  return (
    <div className="max-w-4xl mx-auto space-y-16">
      <section className="flex flex-col md:flex-row gap-8 items-center">
        <img
          src="https://images.unsplash.com/photo-1494790108377-be9c29b29330"
          alt="Aima Iftikhar"
          className="rounded-full w-48 h-48 object-cover border-4 border-primary/20"
          loading="eager" // Load this image immediately
        />
        <div className="space-y-4">
          <h1 className="text-4xl font-bold bg-gradient-to-r from-primary to-purple-600 text-transparent bg-clip-text">
            Aima Iftikhar
          </h1>
          <p className="text-lg text-muted-foreground leading-relaxed">
            Creative writer and storyteller with a passion for crafting engaging narratives. 
            Specializing in cultural commentary, personal essays, and digital content creation 
            that bridges traditional and modern storytelling.
          </p>
          <div className="flex gap-4">
            <a href="https://twitter.com" target="_blank" rel="noopener noreferrer">
              <SiX className="w-6 h-6 text-muted-foreground hover:text-primary transition-colors" />
            </a>
            <a href="https://linkedin.com" target="_blank" rel="noopener noreferrer">
              <SiLinkedin className="w-6 h-6 text-muted-foreground hover:text-primary transition-colors" />
            </a>
            <a href="https://medium.com" target="_blank" rel="noopener noreferrer">
              <SiMedium className="w-6 h-6 text-muted-foreground hover:text-primary transition-colors" />
            </a>
          </div>
        </div>
      </section>

      <section>
        <h2 className="text-3xl font-bold mb-8 bg-gradient-to-r from-primary to-purple-600 text-transparent bg-clip-text">
          Freelance Profiles
        </h2>
        {isProfilesLoading ? (
          <ProfilesSkeleton />
        ) : (
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {freelanceProfiles?.map((profile) => {
              const Icon = platformIcons[profile.iconName.toLowerCase()];
              return (
                <a
                  key={profile.id}
                  href={profile.profileUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="group"
                >
                  <Card className="hover:border-primary/50 transition-colors">
                    <CardContent className="p-6 flex flex-col items-center gap-3">
                      {Icon && (
                        <Icon className="w-8 h-8 text-muted-foreground group-hover:text-primary transition-colors" />
                      )}
                      <span className="text-sm font-medium text-muted-foreground group-hover:text-primary transition-colors">
                        {profile.platform}
                      </span>
                    </CardContent>
                  </Card>
                </a>
              );
            })}
          </div>
        )}
      </section>

      <section>
        <div className="flex justify-between items-center mb-8">
          <h2 className="text-3xl font-bold bg-gradient-to-r from-primary to-purple-600 text-transparent bg-clip-text">
            Featured Works
          </h2>
          <Link href="/works">
            <Button variant="outline" className="border-primary hover:bg-primary/5">
              View All Works
            </Button>
          </Link>
        </div>

        {isWorksLoading ? (
          <WorksSkeleton />
        ) : (
          <div className="grid md:grid-cols-2 gap-6">
            {works?.slice(0, 2).map((work) => (
              <Card key={work.id} className="group hover:border-primary/50 transition-colors">
                <CardContent className="p-6 space-y-4">
                  <img
                    src={work.imageUrl}
                    alt={work.title}
                    className="w-full h-48 object-cover rounded-md group-hover:opacity-90 transition-opacity"
                    loading="lazy"
                  />
                  <div>
                    <h3 className="text-xl font-semibold group-hover:text-primary transition-colors">
                      {work.title}
                    </h3>
                    <p className="text-muted-foreground mt-2">{work.excerpt}</p>
                    <div className="flex items-center gap-2 mt-4 text-sm text-muted-foreground">
                      <Clock className="w-4 h-4" />
                      <span>{work.readingTime} min read</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </section>
    </div>
  );
}