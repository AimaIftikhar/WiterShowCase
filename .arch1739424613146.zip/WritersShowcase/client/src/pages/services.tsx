import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import {
  PenTool,
  BookOpen,
  Edit,
  FileText,
  BookType,
  GraduationCap,
  Code,
  Copy
} from "lucide-react";

const services = [
  {
    icon: PenTool,
    title: "Article Writing",
    description: "Well-researched, engaging articles tailored to your specific niche and audience.",
  },
  {
    icon: FileText,
    title: "Blog Post Writing",
    description: "SEO-optimized blog posts that drive traffic and engage readers.",
  },
  {
    icon: Copy,
    title: "Copywriting",
    description: "Compelling copy that converts visitors into customers.",
  },
  {
    icon: Edit,
    title: "Editing & Proofreading",
    description: "Thorough editing and proofreading to polish your content to perfection.",
  },
  {
    icon: BookOpen,
    title: "Book Writing",
    description: "Full-length books crafted with your unique voice and vision.",
  },
  {
    icon: BookType,
    title: "Ghost Writing",
    description: "Professional ghost writing services for various content types.",
  },
  {
    icon: Code,
    title: "Technical Writing",
    description: "Clear, concise technical documentation and content.",
  },
  {
    icon: GraduationCap,
    title: "Academic Writing",
    description: "Well-researched academic content across various disciplines.",
  }
];

export default function Services() {
  return (
    <div className="max-w-4xl mx-auto">
      <div className="text-center mb-12">
        <h1 className="text-4xl font-bold mb-4 bg-gradient-to-r from-primary to-purple-600 text-transparent bg-clip-text">
          Writing Services
        </h1>
        <p className="text-lg text-muted-foreground">
          Professional writing services tailored to your needs
        </p>
      </div>

      <div className="grid md:grid-cols-2 gap-6">
        {services.map((service) => (
          <Card key={service.title} className="group hover:border-primary/50 transition-colors">
            <CardContent className="p-6">
              <div className="flex items-start gap-4">
                <service.icon className="w-8 h-8 text-primary" />
                <div>
                  <h3 className="text-xl font-semibold mb-2 group-hover:text-primary transition-colors">
                    {service.title}
                  </h3>
                  <p className="text-muted-foreground mb-4">
                    {service.description}
                  </p>
                  <Link href="/contact">
                    <Button variant="outline" className="border-primary hover:bg-primary/5">
                      Get Started
                    </Button>
                  </Link>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}
