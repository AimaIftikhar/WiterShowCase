import { Card, CardContent } from "@/components/ui/card";
import { useQuery } from "@tanstack/react-query";
import { Work } from "@shared/schema";
import { Clock, FileText } from "lucide-react";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";

export default function Works() {
  const { data: works, isLoading } = useQuery<Work[]>({
    queryKey: ["/api/works"],
    staleTime: 1000 * 60 * 5 // Cache for 5 minutes
  });

  if (isLoading) {
    return (
      <div className="max-w-4xl mx-auto">
        <h1 className="text-4xl font-bold mb-8 bg-gradient-to-r from-primary to-purple-600 text-transparent bg-clip-text">
          My Works
        </h1>
        <div className="grid md:grid-cols-2 gap-6">
          {[1, 2, 3, 4].map((i) => (
            <Card key={i} className="animate-pulse">
              <CardContent className="p-6">
                <div className="w-full h-48 bg-muted rounded-md mb-4" />
                <div className="space-y-2">
                  <div className="h-6 bg-muted rounded w-3/4" />
                  <div className="h-4 bg-muted rounded w-full" />
                  <div className="h-4 bg-muted rounded w-1/4" />
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto">
      <h1 className="text-4xl font-bold mb-8 bg-gradient-to-r from-primary to-purple-600 text-transparent bg-clip-text">
        My Works
      </h1>
      <div className="grid md:grid-cols-2 gap-6">
        {works?.map((work) => (
          <Card key={work.id} className="group hover:border-primary/50 transition-colors">
            <CardContent className="p-6 space-y-4">
              {/* Image optimization recommendations */}
              <img
                src={work.imageUrl}
                alt={work.title}
                className="w-full h-48 object-cover rounded-md group-hover:opacity-90 transition-opacity"
                loading="lazy"
                width="400"
                height="192"
                decoding="async"
              />
              <div>
                <h2 className="text-xl font-semibold group-hover:text-primary transition-colors">
                  {work.title}
                </h2>
                <p className="text-muted-foreground mt-2">{work.excerpt}</p>
                <div className="flex items-center justify-between mt-4">
                  <div className="flex items-center gap-2 text-sm text-muted-foreground">
                    <Clock className="w-4 h-4" />
                    <span>{work.readingTime} min read</span>
                  </div>
                  {work.documentUrl && (
                    <Link href={`/works/${work.id}`}>
                      <Button variant="outline" className="gap-2 border-primary hover:bg-primary/5">
                        <FileText className="w-4 h-4" />
                        View Document
                      </Button>
                    </Link>
                  )}
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}