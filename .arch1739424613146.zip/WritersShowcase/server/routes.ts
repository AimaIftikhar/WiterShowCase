import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertMessageSchema, insertFreelanceProfileSchema } from "@shared/schema";

export function registerRoutes(app: Express): Server {
  app.get("/api/works", async (_req, res) => {
    const works = await storage.getAllWorks();
    res.json(works);
  });

  app.get("/api/works/:id", async (req, res) => {
    const work = await storage.getWork(Number(req.params.id));
    if (!work) {
      res.status(404).json({ message: "Work not found" });
      return;
    }
    res.json(work);
  });

  app.post("/api/contact", async (req, res) => {
    const result = insertMessageSchema.safeParse(req.body);
    if (!result.success) {
      res.status(400).json({ message: "Invalid message data" });
      return;
    }

    const message = await storage.createMessage(result.data);
    res.status(201).json(message);
  });

  app.get("/api/freelance-profiles", async (_req, res) => {
    const profiles = await storage.getAllFreelanceProfiles();
    res.json(profiles);
  });

  app.post("/api/freelance-profiles", async (req, res) => {
    const result = insertFreelanceProfileSchema.safeParse(req.body);
    if (!result.success) {
      res.status(400).json({ message: "Invalid profile data" });
      return;
    }

    const profile = await storage.createFreelanceProfile(result.data);
    res.status(201).json(profile);
  });

  return createServer(app);
}