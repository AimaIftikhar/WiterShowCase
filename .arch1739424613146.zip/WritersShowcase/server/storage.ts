import { type Work, type Message, type FreelanceProfile, type InsertWork, type InsertMessage, type InsertFreelanceProfile, works, messages, freelanceProfiles } from "@shared/schema";
import { db } from "./db";
import { eq } from "drizzle-orm";

export interface IStorage {
  getAllWorks(): Promise<Work[]>;
  getWork(id: number): Promise<Work | undefined>;
  createMessage(message: InsertMessage): Promise<Message>;
  getAllFreelanceProfiles(): Promise<FreelanceProfile[]>;
  createFreelanceProfile(profile: InsertFreelanceProfile): Promise<FreelanceProfile>;
}

export class DatabaseStorage implements IStorage {
  async getAllWorks(): Promise<Work[]> {
    return await db.select().from(works);
  }

  async getWork(id: number): Promise<Work | undefined> {
    const [work] = await db.select().from(works).where(eq(works.id, id));
    return work;
  }

  async createMessage(message: InsertMessage): Promise<Message> {
    const [newMessage] = await db.insert(messages).values(message).returning();
    return newMessage;
  }

  async getAllFreelanceProfiles(): Promise<FreelanceProfile[]> {
    return await db.select().from(freelanceProfiles);
  }

  async createFreelanceProfile(profile: InsertFreelanceProfile): Promise<FreelanceProfile> {
    const [newProfile] = await db.insert(freelanceProfiles).values(profile).returning();
    return newProfile;
  }
}

export const storage = new DatabaseStorage();