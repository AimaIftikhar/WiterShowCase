import { pgTable, text, serial, integer, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const works = pgTable("works", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  excerpt: text("excerpt").notNull(),
  content: text("content").notNull(),
  imageUrl: text("image_url").notNull(),
  documentUrl: text("document_url"), // URL for uploaded document
  readingTime: integer("reading_time").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const messages = pgTable("messages", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  email: text("email").notNull(),
  message: text("message").notNull(),
});

export const freelanceProfiles = pgTable("freelance_profiles", {
  id: serial("id").primaryKey(),
  platform: text("platform").notNull(),
  profileUrl: text("profile_url").notNull(),
  iconName: text("icon_name").notNull(),
});

export const insertWorkSchema = createInsertSchema(works).omit({ id: true, createdAt: true });
export const insertMessageSchema = createInsertSchema(messages).omit({ id: true });
export const insertFreelanceProfileSchema = createInsertSchema(freelanceProfiles).omit({ id: true });

export type InsertWork = z.infer<typeof insertWorkSchema>;
export type InsertMessage = z.infer<typeof insertMessageSchema>;
export type InsertFreelanceProfile = z.infer<typeof insertFreelanceProfileSchema>;
export type Work = typeof works.$inferSelect;
export type Message = typeof messages.$inferSelect;
export type FreelanceProfile = typeof freelanceProfiles.$inferSelect;